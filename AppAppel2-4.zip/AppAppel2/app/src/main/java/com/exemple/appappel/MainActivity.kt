package com.exemple.appappel

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var etNumero: EditText
    private lateinit var btnAppeler: Button
    private val PERMISSION_CALL = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etNumero = findViewById(R.id.etNumero)
        btnAppeler = findViewById(R.id.btnAppeler)

        btnAppeler.setOnClickListener {
            verifierEtAppeler()
        }
    }

    private fun verifierEtAppeler() {
        val numero = etNumero.text.toString().trim()
        if (numero.isEmpty()) {
            Toast.makeText(this, "Numéro vide", Toast.LENGTH_SHORT).show()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CALL_PHONE), PERMISSION_CALL)
        } else {
            lancerAppel(numero)
        }
    }

    private fun lancerAppel(numero: String) {
        val intent = Intent(Intent.ACTION_CALL)
        intent.data = Uri.parse("tel:$numero")
        startActivity(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_CALL && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            lancerAppel(etNumero.text.toString().trim())
        } else {
            Toast.makeText(this, "Permission refusée.", Toast.LENGTH_LONG).show()
        }
    }
}
